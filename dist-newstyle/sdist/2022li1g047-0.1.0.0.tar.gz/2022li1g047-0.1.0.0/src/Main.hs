{- |
Module      : Tarefa6_2022li1g047
Description : Movimentação do personagem e obstáculos
Copyright   : Afonso Dionísio Santos <a104276@alunos.uminho.pt>
              Luis Enrique Diaz de Freitas <a104000@alunos.uminho.pt>

Módulo para a realização da Tarefa 3 do projeto de LI1 em 2022/23.
-}
module Main where

-------------------------------
main :: IO ()
main = putStrLn "Hello, Haskell!"
